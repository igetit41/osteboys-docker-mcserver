All The Mods 9
======
All The Mods 9 is released on curseforge only, as All Rights Reserved,
This covers the following files/folders
- all Quests and rewards in `\instance\config\ftbquests\quests\`
- all custom Kubejs scripts in `\instance\kubejs\`
- all custom AllTheMods Packmenu assets in `\instance\packmenu\resources\`

What does All Rights Reserved Mean?
For players, it means nothing, you are still permitted to play and film and stream the pack.
For anyone else, it means you cannot redistribute any of the above folders or files in any publicly released packs without permission from Allthemods
