ServerEvents.recipes(e =>{
    e.remove({id: 'everythingcopper:copper_shield'})
})