ServerEvents.recipes(event =>{
    event.shapeless('9x deepresonance:resonating_plate', 'deepresonance:resonating_plate_block').id('kubejs:deepresonance/crafting/resonating_plate')
})