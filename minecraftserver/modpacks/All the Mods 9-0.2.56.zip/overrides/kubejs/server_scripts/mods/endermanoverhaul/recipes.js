ServerEvents.recipes(event => {
    event.shapeless('minecraft:ender_pearl', ['#endermanoverhaul:ender_pearls'])
  })