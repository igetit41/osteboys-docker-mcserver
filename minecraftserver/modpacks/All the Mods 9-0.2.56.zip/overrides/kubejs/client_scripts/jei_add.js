JEIEvents.addItems(event => {
  event.add(Item.of('ae2:facade', '{item:"minecraft:stone"}'))
})